class HashController < ApplicationController
  def mostrar
    @persona = {
      nombre: "joshua",
      apellido: "mendoza",
      telefono: "8885-0942",
      correo: "jmms301199@gmail.com"
    }
  end
end
